import Saluto from "./Saluto";

const ComponentePadre = () => {
    return (
        <div>
            {/*Visualizzazione del componente Saluto*/}
            <Saluto/>
        </div>
    );
}

export default ComponentePadre;