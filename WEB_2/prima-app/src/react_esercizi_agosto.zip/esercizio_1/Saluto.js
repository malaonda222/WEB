import React from 'react'

const Saluto = () => {
    return (
        <h1>Benvenuto nel mio primo componente React!</h1>
    );
};

export default Saluto;