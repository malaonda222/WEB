import MenuRistorante from "./MenuRistorante";

const ComponentePadre = () => {
    return (
        <div>
            <MenuRistorante/>
        </div>
    );
};

export default ComponentePadre;