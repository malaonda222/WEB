import Termostato from "./Termostato";

const ComponentePadre = () => {
    return (
        <div>
            <Termostato/>
        </div>
    );
};

export default ComponentePadre;