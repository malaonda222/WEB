import CampoRicerca from "./CampoRicerca";

const ComponentePadre = () => {
    return (
        <CampoRicerca/>
    );
};


export default ComponentePadre;
