import MessaggioSegreto from "./MessaggioSegreto";

const ComponentePadre = () => {
  return (
    <div>
      <MessaggioSegreto />
    </div>
  );
};

export default ComponentePadre;