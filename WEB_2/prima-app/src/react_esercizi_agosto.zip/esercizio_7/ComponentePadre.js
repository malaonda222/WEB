import AggiornaTitolo from "./AggiornaTitolo";

const ComponentePadre = () => {
    return(
    <AggiornaTitolo/>
    );
};

export default ComponentePadre;