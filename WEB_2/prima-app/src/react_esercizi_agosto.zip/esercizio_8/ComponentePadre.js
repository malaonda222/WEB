import GalleriaFoto from "./GalleriaFoto";

const ComponentePadre = () => {
    return (
        <div>
            <GalleriaFoto/>
        </div>
    );
};

export default ComponentePadre;