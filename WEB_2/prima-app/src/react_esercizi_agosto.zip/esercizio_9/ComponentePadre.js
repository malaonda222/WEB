import ModuloContatti from "./ModuloContatti";

const ComponentePadre = () => {
    return (
        <div>
            <ModuloContatti/>
        </div>
    );
};

export default ComponentePadre;